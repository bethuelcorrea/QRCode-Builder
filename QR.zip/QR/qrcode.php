<?php




require_once 'vendor/autoload.php';

if(isset($_POST['text'])){

	
	if(!empty($_POST['download'])){
		//This will download the qr code!!
		header('Content-Disposition: attachment; filename=qr.png');
		
		$size = !empty($_POST['size']) ? $_POST['size'] : 200;
		$padding = !empty($_POST['padding']) ? $_POST['padding'] : 10;

		$qr = new Endroid\QrCode\QrCode();
		$qr->setText($_POST['text']);
		$qr->setSize($size);
		$qr->setPadding($padding);


		$qr->render();		
	
	}else{
		//This will display and not download
		header('Content-Type: image/png');
		
		$size = !empty($_POST['size']) ? $_POST['size'] : 200;
		$padding = !empty($_POST['padding']) ? $_POST['padding'] : 10;

		$qr = new Endroid\QrCode\QrCode();
		$qr->setText($_POST['text']);
		$qr->setSize($size);
		$qr->setPadding($padding);


		$qr->render();		
				
	}
		
	
	
	
	
	




}

?>

