<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create QR</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	 
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>



</head>
<body>
<div class="container">
	
  <div class="jumbotron">
  <h1 class="display-4">QR Generator</h1>
  <p class="lead">Check the box to download file to your computer.</p>
  
		<div class="alert alert-info">
  			<strong>Default Settings If Input Is Empty </strong> size: 200 | padding:10 
		</div>  
	  
  <hr class="my-4">
  </div>	
	
	
<form action="qrcode.php" method="post">

	<div class="form-group">	
	 <label for="text">Text:</label>
     <input class="form-control" type="text" name="text" id="text" required>
    </div>
	
	<div class="form-group">
	<label for="size">Size:</label>    
    <input class="form-control" type="text" name="size" id="size">
	</div>	

	<div class="form-group">
	<label for="padding">Padding:</label>	
    <input class="form-control" type="text" name="padding" id="padding">
	</div>
	
	<div class="form-check">
	<input type="checkbox" name="download" id="download" value="1">
	<label class="form-check-label" for="download">check to download</label>
	</div>	
	
	<div class="form-group">
    <button type="submit" class="btn btn-primary">Create QR</button>
	</div>

</form>
	
</div>  
	
	
</body>
</html>